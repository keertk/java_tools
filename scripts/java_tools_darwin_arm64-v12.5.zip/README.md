This Java tools version was built from the bazel repository at commit hash 35f81b40dbfb6709c47713c1e22849a0a8dd6df0
using bazel version 6.2.1 on platform darwin_arm64.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout 35f81b40dbfb6709c47713c1e22849a0a8dd6df0
$ bazel build //src:java_tools_prebuilt.zip
