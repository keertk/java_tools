This Java tools version was built from the bazel repository at commit hash 5c4cf47a131c84506aad9ce0e014c6643c31a4ac
using bazel version 6.2.1 on platform darwin_arm64.
To build from source the same zip run the commands:

$ git clone https://github.com/bazelbuild/bazel.git
$ git checkout 5c4cf47a131c84506aad9ce0e014c6643c31a4ac
$ bazel build //src:java_tools_prebuilt.zip
